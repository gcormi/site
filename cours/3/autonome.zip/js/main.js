/**
 * Script principal pour l'application éducative autonome
 * Gère toutes les interactions utilisateur et animations
 */

// Fonction d'initialisation principale
function initializeApp() {
  setupNavigation();
  setupExpandables();
  setupImageModals();
  setupBackToTop();
  setupDarkMode();
  animateOnScroll();
  setupGlossaryTerms();
  setupDiagrams();
}

// Navigation par sections
function setupNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Supprime la classe active de tous les liens
      navLinks.forEach(l => l.classList.remove('active'));
      
      // Ajoute la classe active au lien cliqué
      this.classList.add('active');
      
      // Fait défiler jusqu'à la section
      const targetId = this.getAttribute('href').substring(1);
      const targetSection = document.getElementById(targetId);
      
      if (targetSection) {
        window.scrollTo({
          top: targetSection.offsetTop - 100,
          behavior: 'smooth'
        });
      }
    });
  });
}

// Contenu extensible
function setupExpandables() {
  const triggers = document.querySelectorAll('.expandable-trigger');
  
  triggers.forEach(trigger => {
    trigger.addEventListener('click', function() {
      const content = this.parentElement;
      content.classList.toggle('active');
      
      if(content.classList.contains('active')) {
        this.querySelector('i').classList.replace('fa-chevron-down', 'fa-chevron-up');
      } else {
        this.querySelector('i').classList.replace('fa-chevron-up', 'fa-chevron-down');
      }
    });
  });
}

// Fenêtres modales pour les images
function setupImageModals() {
  const zoomableImages = document.querySelectorAll('.zoomable-image');
  
  zoomableImages.forEach(img => {
    img.addEventListener('click', function() {
      const modal = document.getElementById('imageModal');
      const modalImg = document.getElementById('zoomImage');
      
      modal.classList.add('active');
      modalImg.src = this.src;
    });
  });
  
  // Fermeture de la modale
  const closeBtn = document.querySelector('.image-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeImageModal);
  }
  
  // Fermeture en cliquant en dehors de l'image
  const modal = document.getElementById('imageModal');
  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === this) {
        closeImageModal();
      }
    });
  }
}

function closeImageModal() {
  const modal = document.getElementById('imageModal');
  if (modal) {
    modal.classList.remove('active');
  }
}

// Bouton retour en haut
function setupBackToTop() {
  const backToTopButton = document.getElementById('backToTop');
  
  if (backToTopButton) {
    window.addEventListener('scroll', function() {
      if(window.pageYOffset > 300) {
        backToTopButton.classList.add('visible');
      } else {
        backToTopButton.classList.remove('visible');
      }
    });
    
    backToTopButton.addEventListener('click', function() {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }
}

// Mode sombre
function setupDarkMode() {
  const darkToggle = document.querySelector('.dark-toggle');
  
  if (darkToggle) {
    darkToggle.addEventListener('click', toggleDarkMode);
    
    // Appliquer le mode préféré au chargement
    if(localStorage.getItem('darkMode') === 'enabled') {
      document.body.classList.add('dark-mode');
      const icon = darkToggle.querySelector('i');
      if (icon) {
        icon.classList.replace('fa-moon', 'fa-sun');
      }
    }
  }
}

function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
  
  const icon = document.querySelector('.dark-toggle i');
  
  // Sauvegarde de la préférence
  if(document.body.classList.contains('dark-mode')) {
    localStorage.setItem('darkMode', 'enabled');
    if (icon) {
      icon.classList.replace('fa-moon', 'fa-sun');
    }
  } else {
    localStorage.setItem('darkMode', 'disabled');
    if (icon) {
      icon.classList.replace('fa-sun', 'fa-moon');
    }
  }
}

// Animation au défilement
function animateOnScroll() {
  const elements = document.querySelectorAll('.animate-on-scroll');
  
  if (elements.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if(entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, {
      threshold: 0.1
    });
    
    elements.forEach(element => {
      observer.observe(element);
    });
  }
}

// Fenêtres modales pour les termes du glossaire
function setupGlossaryTerms() {
  const terms = document.querySelectorAll('.glossary-term');
  
  terms.forEach(term => {
    term.addEventListener('click', function() {
      // Les arguments pour showInfoModal sont définis via l'attribut onclick sur chaque terme
    });
  });
  
  // Fermeture de la modale d'information
  const closeInfoBtn = document.querySelector('.modal-close');
  if (closeInfoBtn) {
    closeInfoBtn.addEventListener('click', closeInfoModal);
  }
  
  // Fermeture en cliquant en dehors du contenu
  const infoModal = document.getElementById('infoModal');
  if (infoModal) {
    infoModal.addEventListener('click', function(e) {
      if (e.target === this) {
        closeInfoModal();
      }
    });
  }
}

function showInfoModal(title, content) {
  const modalTitle = document.getElementById('modalTitle');
  const modalContent = document.getElementById('modalContent');
  const modal = document.getElementById('infoModal');
  
  if (modalTitle && modalContent && modal) {
    modalTitle.textContent = title;
    modalContent.textContent = content;
    modal.classList.add('active');
  }
}

function closeInfoModal() {
  const modal = document.getElementById('infoModal');
  if (modal) {
    modal.classList.remove('active');
  }
}

// Diagrammes interactifs
function setupDiagrams() {
  const chainElements = document.querySelectorAll('.chain-element');
  
  chainElements.forEach(element => {
    element.addEventListener('click', function() {
      const title = this.querySelector('h4').textContent;
      const description = this.getAttribute('data-description');
      
      if (description) {
        showInfoModal(title, description);
      }
    });
  });
}

// Écouter le chargement complet du document
document.addEventListener('DOMContentLoaded', initializeApp);